/**
 * 
 */
/**
 * @author Chirag
 *
 */
module CoreJavaTrainingPractice {
}