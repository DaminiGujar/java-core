package com.learning.core.day1session2.ps4;

public class D01P04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
