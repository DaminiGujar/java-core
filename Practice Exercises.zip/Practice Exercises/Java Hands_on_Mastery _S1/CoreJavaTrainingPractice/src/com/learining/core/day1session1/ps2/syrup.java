package com.learining.core.day1session1.ps2;

public class syrup implements MedicineInfo{
	
	
	@Override
	public void displayLabel() {
		System.out.println("Syrup is consumable only on prescription.");
	}
}
