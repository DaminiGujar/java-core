package com.learining.core.day1session1.ps2;

public class Tablet implements MedicineInfo {
	
	@Override
	public void displayLabel() {
		System.out.println("Store Tablets in a cool dry place.");
	}

}
