package com.learining.core.day1session1.ps2;

public class D01P02 {

	public static void main(String[] args) {
		
		Tablet tablet = new Tablet();
		syrup syrp = new syrup();
		Ointment ointment = new Ointment();
		
		tablet.displayLabel();
		syrp.displayLabel();
		ointment.displayLabel();

	}

}
