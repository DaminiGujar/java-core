package com.learining.core.day1session1.ps2;

public interface MedicineInfo {
	
	void displayLabel();

}
